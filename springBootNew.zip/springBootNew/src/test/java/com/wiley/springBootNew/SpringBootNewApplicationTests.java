package com.wiley.springBootNew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
