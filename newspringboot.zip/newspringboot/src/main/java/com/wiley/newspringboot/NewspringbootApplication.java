package com.wiley.newspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewspringbootApplication.class, args);
	}

}
